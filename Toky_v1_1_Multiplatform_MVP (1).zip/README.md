# Toky v1.1 — cross-platform short-video MVP starter

Brand: Toky. Visual identity: near-black `#08090d` with pink `#ff3d75`.
Languages included in starter UI: English, Arabic, Spanish, French, Turkish, Hindi.
Target platforms: Android, iOS and web through Expo / React Native.

## What's included
- Vertical paged short-video feed mockup with creator controls
- Like, follow, share interactions (demo/local state)
- Language toggle between English and Arabic in the feed; translation dictionary scaffold for six languages
- Email/password sign-up and sign-in screen using Supabase Auth
- Video picker and upload flow to Supabase Storage + video metadata insert
- Profile, discover, inbox and comments placeholder screens
- SQL schema and initial RLS policies for profiles, videos, likes, comments, follows, reports and storage objects

## Run
1. Install Node.js LTS.
2. Extract the ZIP and run `npm install`.
3. Copy `.env.example` to `.env` and enter your Supabase project URL and anon key.
4. In Supabase SQL Editor, run `supabase/schema.sql`.
5. In Supabase Dashboard, create a Storage bucket called `videos`, configure size/MIME restrictions, and set email confirmation settings.
6. Run `npm run start`; use Expo Go for device testing or `npm run web` for web.

## Important implementation status
This is an MVP starter, not a finished production social network. The current feed uses demo visual cards and does not yet stream uploaded videos. The language dictionaries are provided, but the UI language selector is only wired for English/Arabic in the feed. Comments, DMs, push notifications, live streaming, moderation dashboard, recommendations, account recovery, profile creation trigger, and real feed pagination still need implementation. The upload flow should be tested on real devices; the base64 upload approach is suitable only for small MVP clips and should be replaced by resumable uploads for production.

## Before public launch
- Implement server-side moderation, abuse reporting review, rate limits and spam controls.
- Review RLS policies with security testing; do not expose service-role keys in client apps.
- Use private storage and signed URLs if videos should not be publicly accessible.
- Add privacy policy, terms, age-appropriate safety flows, data deletion and consent.
- Add video transcoding/adaptive streaming, CDN delivery, thumbnails and recommendation ranking.
- Configure app identifiers, signing, store accounts, app icons, screenshots and release builds.
