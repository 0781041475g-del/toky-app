create extension if not exists pgcrypto;
create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 username text unique not null,
 display_name text, avatar_url text, bio text, created_at timestamptz default now()
);
create table if not exists public.videos (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id) on delete cascade,
 caption text default '', video_url text not null, thumbnail_url text,
 music_title text, created_at timestamptz default now()
);
create table if not exists public.likes (
 user_id uuid references public.profiles(id) on delete cascade,
 video_id uuid references public.videos(id) on delete cascade,
 created_at timestamptz default now(), primary key(user_id,video_id)
);
create table if not exists public.comments (
 id uuid primary key default gen_random_uuid(),
 user_id uuid references public.profiles(id) on delete cascade,
 video_id uuid references public.videos(id) on delete cascade,
 body text not null, created_at timestamptz default now()
);
create table if not exists public.follows (
 follower_id uuid references public.profiles(id) on delete cascade,
 followed_id uuid references public.profiles(id) on delete cascade,
 created_at timestamptz default now(), primary key(follower_id,followed_id),
 check(follower_id<>followed_id)
);
create table if not exists public.reports (
 id uuid primary key default gen_random_uuid(),
 reporter_id uuid references public.profiles(id) on delete cascade,
 video_id uuid references public.videos(id) on delete cascade,
 reason text not null, created_at timestamptz default now()
);
alter table public.profiles enable row level security;
alter table public.videos enable row level security;
alter table public.likes enable row level security;
alter table public.comments enable row level security;
alter table public.follows enable row level security;
alter table public.reports enable row level security;
create policy "profiles readable" on public.profiles for select using(true);
create policy "profile insert self" on public.profiles for insert with check(auth.uid()=id);
create policy "profile update self" on public.profiles for update using(auth.uid()=id);
create policy "videos readable" on public.videos for select using(true);
create policy "video insert self" on public.videos for insert with check(auth.uid()=user_id);
create policy "video update self" on public.videos for update using(auth.uid()=user_id);
create policy "video delete self" on public.videos for delete using(auth.uid()=user_id);
create policy "likes readable" on public.likes for select using(true);
create policy "likes insert self" on public.likes for insert with check(auth.uid()=user_id);
create policy "likes delete self" on public.likes for delete using(auth.uid()=user_id);
create policy "comments readable" on public.comments for select using(true);
create policy "comments insert self" on public.comments for insert with check(auth.uid()=user_id);
create policy "comments delete self" on public.comments for delete using(auth.uid()=user_id);
create policy "follows readable" on public.follows for select using(true);
create policy "follows insert self" on public.follows for insert with check(auth.uid()=follower_id);
create policy "follows delete self" on public.follows for delete using(auth.uid()=follower_id);
create policy "reports insert self" on public.reports for insert with check(auth.uid()=reporter_id);

-- Create a Storage bucket named "videos" from Supabase Dashboard, then apply:
-- Restrict uploads to authenticated users, max file size and MIME types in Dashboard.
create policy "public read videos" on storage.objects for select using(bucket_id='videos');
create policy "authenticated upload own folder" on storage.objects for insert to authenticated
 with check(bucket_id='videos' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "owner delete own videos" on storage.objects for delete to authenticated
 using(bucket_id='videos' and (storage.foldername(name))[1]=auth.uid()::text);
