export const demoClips = [
 {id:'demo-1',username:'sara.vibes',caption:'Little moments make big memories ✨',likes:12800,comments:342,color:'#5636a8',music:'Original audio · sara',avatar:'S'},
 {id:'demo-2',username:'ali.creates',caption:'Greetings from Baghdad 🇮🇶',likes:8450,comments:216,color:'#087f83',music:'Baghdad nights',avatar:'A'},
 {id:'demo-3',username:'noor.food',caption:'A quick recipe you have to try 🍓',likes:23100,comments:891,color:'#a74766',music:'Sweet mood',avatar:'N'}
];
