import React,{useEffect,useState} from 'react';
import {View,Text,StyleSheet,Pressable,Alert} from 'react-native';
import {supabase} from '../lib/supabase';
import {useRouter} from 'expo-router';
export default function Profile(){
 const [email,setEmail]=useState('Guest');const router=useRouter();
 useEffect(()=>{supabase?.auth.getUser().then(({data})=>setEmail(data.user?.email||'Guest'));},[]);
 async function signOut(){await supabase?.auth.signOut();setEmail('Guest');Alert.alert('Signed out','You have been signed out.');}
 return <View style={s.page}><Text style={s.logo}>TOKY.</Text><View style={s.avatar}>T</View><Text style={s.name}>Toky Creator</Text><Text style={s.handle}>{email}</Text><View style={s.stats}><Text style={s.stat}>0{"\n"}Followers</Text><Text style={s.stat}>0{"\n"}Following</Text><Text style={s.stat}>0{"\n"}Likes</Text></View><Pressable style={s.btn} onPress={()=>router.push('/auth')}><Text style={s.btnText}>Sign in / Create account</Text></Pressable><Pressable style={s.outline} onPress={()=>router.push('/upload')}><Text style={s.btnText}>Upload a video</Text></Pressable><Pressable style={s.link} onPress={signOut}><Text style={{color:'#ff779c'}}>Sign out</Text></Pressable></View>
}
const s=StyleSheet.create({page:{flex:1,backgroundColor:'#08090d',alignItems:'center',padding:22,paddingTop:60},logo:{alignSelf:'flex-start',fontSize:24,fontWeight:'900',color:'white'},avatar:{marginTop:55,width:90,height:90,borderRadius:50,backgroundColor:'#ff3d75',alignItems:'center',justifyContent:'center',fontSize:30,color:'white',fontWeight:'900'},name:{color:'white',fontSize:21,fontWeight:'900',marginTop:15},handle:{color:'#999',marginTop:5},stats:{flexDirection:'row',gap:35,marginTop:28},stat:{color:'white',textAlign:'center',fontWeight:'800',lineHeight:24},btn:{marginTop:28,backgroundColor:'#ff3d75',padding:14,borderRadius:9,width:'100%',alignItems:'center'},outline:{marginTop:10,borderColor:'#555',borderWidth:1,padding:14,borderRadius:9,width:'100%',alignItems:'center'},btnText:{color:'white',fontWeight:'800'},link:{marginTop:25}});
