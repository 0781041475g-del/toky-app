import React,{useState} from 'react';
import {View,Text,TextInput,Pressable,StyleSheet,Alert,ActivityIndicator} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system';
import {supabase} from '../lib/supabase';
import {useRouter} from 'expo-router';
export default function Upload(){
 const [asset,setAsset]=useState<ImagePicker.ImagePickerAsset|null>(null);const [caption,setCaption]=useState('');const [busy,setBusy]=useState(false);const router=useRouter();
 async function choose(){const p=await ImagePicker.requestMediaLibraryPermissionsAsync();if(!p.granted){Alert.alert('Permission needed','Allow media access to choose a video.');return;}const r=await ImagePicker.launchImageLibraryAsync({mediaTypes:['videos'],quality:1,videoMaxDuration:180});if(!r.canceled)setAsset(r.assets[0]);}
 async function publish(){
  if(!asset){Alert.alert('Choose a video','Select a clip before publishing.');return;}
  if(!supabase){Alert.alert('Backend not connected','Configure Supabase in .env before uploading.');return;}
  const {data:{user}}=await supabase.auth.getUser();if(!user){router.push('/auth');return;}
  setBusy(true);
  try{
   const ext=(asset.fileName?.split('.').pop()||'mp4').toLowerCase();
   const path=`${user.id}/${Date.now()}.${ext}`;
   const base64=await FileSystem.readAsStringAsync(asset.uri,{encoding:FileSystem.EncodingType.Base64});
   const bytes=Uint8Array.from(atob(base64),c=>c.charCodeAt(0));
   const {error:upErr}=await supabase.storage.from('videos').upload(path,bytes,{contentType:asset.mimeType||'video/mp4',upsert:false});
   if(upErr)throw upErr;
   const {data:publicData}=supabase.storage.from('videos').getPublicUrl(path);
   const {error:dbErr}=await supabase.from('videos').insert({user_id:user.id,caption,video_url:publicData.publicUrl});
   if(dbErr)throw dbErr;
   Alert.alert('Published','Your video has been uploaded.');router.replace('/');
  }catch(e:any){Alert.alert('Upload failed',e.message||'Please try again.');}
  finally{setBusy(false);}
 }
 return <View style={s.page}><Text style={s.logo}>TOKY.</Text><Text style={s.title}>Create a moment</Text><Pressable style={s.pick} onPress={choose}><Text style={s.pickText}>{asset?`Selected: ${asset.fileName||'video clip'}`:'＋  Choose a video'}</Text></Pressable><TextInput style={s.caption} value={caption} onChangeText={setCaption} placeholder="Write a caption…" placeholderTextColor="#888" multiline/><Text style={s.note}>Maximum recommended length: 3 minutes. Only upload content you have rights to share.</Text><Pressable style={s.publish} onPress={publish} disabled={busy}>{busy?<ActivityIndicator color="white"/>:<Text style={{color:'white',fontWeight:'900'}}>Publish video</Text>}</Pressable></View>
}
const s=StyleSheet.create({page:{flex:1,backgroundColor:'#08090d',padding:22,paddingTop:60},logo:{fontSize:25,color:'white',fontWeight:'900'},title:{color:'white',fontSize:26,fontWeight:'900',marginTop:38,marginBottom:20},pick:{height:220,borderRadius:18,borderWidth:1,borderColor:'#ff3d75',borderStyle:'dashed',backgroundColor:'#18121a',alignItems:'center',justifyContent:'center',padding:20},pickText:{color:'white',fontWeight:'800',textAlign:'center'},caption:{marginTop:18,minHeight:90,backgroundColor:'#191a22',borderRadius:10,padding:14,color:'white',textAlignVertical:'top'},note:{color:'#888',fontSize:11,marginTop:12,lineHeight:17},publish:{backgroundColor:'#ff3d75',padding:16,borderRadius:10,alignItems:'center',marginTop:22}});
