import React,{useState} from 'react';
import {View,Text,Pressable,StyleSheet,Dimensions,FlatList,Share} from 'react-native';
import {Ionicons} from '@expo/vector-icons';
import {demoClips} from '../data/demo';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import {useRouter} from 'expo-router';
import {Language,t} from '../lib/i18n';

const {height}=Dimensions.get('window');
export default function Feed(){
 const [language,setLanguage]=useState<Language>('en');
 const [liked,setLiked]=useState<string[]>([]);
 const [followed,setFollowed]=useState<string[]>([]);
 const [tab,setTab]=useState<'forYou'|'following'>('forYou');
 const insets=useSafeAreaInsets(); const router=useRouter();
 const label=(key:string)=>t(language,key);
 return <View style={s.screen}>
  <FlatList data={demoClips} keyExtractor={x=>x.id} pagingEnabled showsVerticalScrollIndicator={false}
   renderItem={({item})=>{const isLiked=liked.includes(item.id);return <View style={[s.clip,{backgroundColor:item.color}]}>
    <View style={s.header}><Text style={s.logo}>TOKY<Text style={{color:'#ff3d75'}}>.</Text></Text>
     <View style={s.tabs}><Pressable onPress={()=>setTab('following')}><Text style={[s.tab,tab==='following'&&s.active]}>{label('following')}</Text></Pressable><Pressable onPress={()=>setTab('forYou')}><Text style={[s.tab,tab==='forYou'&&s.active]}>{label('forYou')}</Text></Pressable></View>
     <Pressable onPress={()=>setLanguage(language==='en'?'ar':'en')}><Text style={s.lang}>{language.toUpperCase()}</Text></Pressable>
    </View>
    <View style={s.preview}><View style={s.play}><Ionicons name="play" size={30} color="white"/></View><Text style={s.previewTitle}>TOKY VIDEO</Text><Text style={s.previewSub}>Preview clip · connect video storage to stream</Text></View>
    <View style={[s.details,{bottom:insets.bottom+90}]}><View style={s.creator}><View style={s.avatar}><Text style={{fontWeight:'900'}}>{item.avatar}</Text></View><Text style={s.username}>@{item.username}</Text><Pressable style={s.follow} onPress={()=>setFollowed(a=>a.includes(item.id)?a.filter(x=>x!==item.id):[...a,item.id])}><Text style={s.followText}>{followed.includes(item.id)?label('followingLabel'):label('follow')}</Text></Pressable></View><Text style={s.caption}>{item.caption}</Text><Text style={s.music}>♫  {item.music}</Text></View>
    <View style={[s.actions,{bottom:insets.bottom+100}]}><Pressable onPress={()=>setLiked(a=>isLiked?a.filter(x=>x!==item.id):[...a,item.id])} style={s.action}><Ionicons name={isLiked?'heart':'heart-outline'} size={34} color={isLiked?'#ff3d75':'white'}/><Text style={s.actionText}>{(item.likes+(isLiked?1:0)).toLocaleString()}</Text></Pressable><Pressable style={s.action} onPress={()=>router.push('/comments')}><Ionicons name="chatbubble-ellipses-outline" size={30} color="white"/><Text style={s.actionText}>{item.comments}</Text></Pressable><Pressable style={s.action} onPress={()=>Share.share({message:`${item.caption} · Toky`})}><Ionicons name="paper-plane-outline" size={30} color="white"/><Text style={s.actionText}>{label('share')}</Text></Pressable><View style={s.disc}><Ionicons name="musical-notes" size={18} color="white"/></View></View>
   </View>}}
  />
  <View style={[s.nav,{paddingBottom:Math.max(insets.bottom,9)}]}>
   {([['home',label('forYou'),'/'],['compass-outline',label('discover'),'/discover'],['add-circle',label('upload'),'/upload'],['mail-outline',label('inbox'),'/inbox'],['person-outline',label('profile'),'/profile']] as const).map(([ic,txt,path],i)=><Pressable key={path} style={s.navItem} onPress={()=>path!=='/'&&router.push(path as any)}><Ionicons name={ic as any} size={23} color={i===0?'white':'#888'}/><Text style={[s.navText,i===0&&{color:'white'}]}>{txt}</Text></Pressable>)}
  </View>
 </View>;
}
const s=StyleSheet.create({screen:{flex:1,backgroundColor:'#08090d'},clip:{height,overflow:'hidden'},header:{paddingTop:55,paddingHorizontal:18,flexDirection:'row',justifyContent:'space-between',alignItems:'center'},logo:{fontSize:24,fontWeight:'900',letterSpacing:1.5,color:'white'},tabs:{flexDirection:'row',gap:20},tab:{color:'#ddd',fontSize:14,fontWeight:'700'},active:{color:'white',textDecorationLine:'underline'},lang:{color:'white',fontWeight:'800',fontSize:11},preview:{position:'absolute',top:'39%',alignSelf:'center',alignItems:'center'},play:{width:72,height:72,borderRadius:40,backgroundColor:'#ffffff30',alignItems:'center',justifyContent:'center',borderWidth:1,borderColor:'#ffffff80'},previewTitle:{color:'white',fontSize:17,fontWeight:'900',letterSpacing:3,marginTop:14},previewSub:{color:'#ffffffaa',fontSize:10,marginTop:6},details:{position:'absolute',left:17,right:90},creator:{flexDirection:'row',alignItems:'center',gap:9,marginBottom:11},avatar:{width:34,height:34,borderRadius:20,backgroundColor:'white',alignItems:'center',justifyContent:'center'},username:{color:'white',fontWeight:'800'},follow:{borderWidth:1,borderColor:'white',padding:6,borderRadius:5},followText:{color:'white',fontSize:11,fontWeight:'800'},caption:{color:'white',fontSize:15,fontWeight:'600'},music:{color:'white',fontSize:12,marginTop:10},actions:{position:'absolute',right:13,alignItems:'center',gap:20},action:{alignItems:'center',gap:4},actionText:{color:'white',fontSize:10,fontWeight:'700'},disc:{width:42,height:42,borderRadius:30,backgroundColor:'#333',alignItems:'center',justifyContent:'center',borderWidth:5,borderColor:'#555'},nav:{position:'absolute',bottom:0,left:0,right:0,backgroundColor:'#090a0f',borderTopWidth:1,borderColor:'#252630',flexDirection:'row',justifyContent:'space-around',paddingTop:10},navItem:{alignItems:'center',gap:3},navText:{fontSize:9,color:'#888'}});
