import React from 'react';import {View,Text,StyleSheet} from 'react-native';
export default function Inbox(){return <View style={s.page}><Text style={s.title}>Inbox</Text><Text style={s.sub}>Your messages and notifications will appear here.</Text><Text style={s.note}>Messaging is a planned feature and is not connected yet.</Text></View>}
const s=StyleSheet.create({page:{flex:1,backgroundColor:'#08090d',padding:22,paddingTop:60},title:{color:'white',fontSize:26,fontWeight:'900'},sub:{color:'#aaa',marginTop:18},note:{color:'#777',marginTop:10,fontSize:12}});
