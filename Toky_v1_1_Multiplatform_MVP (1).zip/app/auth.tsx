import React,{useState} from 'react';
import {View,Text,TextInput,Pressable,StyleSheet,Alert,ActivityIndicator} from 'react-native';
import {supabase} from '../lib/supabase';
import {useRouter} from 'expo-router';
export default function Auth(){
 const [mode,setMode]=useState<'in'|'up'>('up');const [email,setEmail]=useState('');const [password,setPassword]=useState('');const [username,setUsername]=useState('');const [busy,setBusy]=useState(false);const router=useRouter();
 async function submit(){
  if(!supabase){Alert.alert('Backend not connected','Add your Supabase URL and anon key to .env first.');return;}
  if(!email.trim()||password.length<8){Alert.alert('Check details','Enter an email and a password of at least 8 characters.');return;}
  setBusy(true);
  const result=mode==='up'?await supabase.auth.signUp({email:email.trim(),password,options:{data:{username:username.trim()}}}):await supabase.auth.signInWithPassword({email:email.trim(),password});
  setBusy(false);
  if(result.error)Alert.alert('Authentication failed',result.error.message);
  else if(mode==='up')Alert.alert('Check your email','Confirm your email to finish creating your Toky account.');
  else router.replace('/');
 }
 return <View style={s.page}><Text style={s.logo}>TOKY<Text style={{color:'#ff3d75'}}>.</Text></Text><Text style={s.heading}>{mode==='up'?'Join the world of Toky':'Welcome back'}</Text><Text style={s.sub}>Short videos. New voices. One world.</Text>
 {mode==='up'&&<TextInput style={s.input} placeholder="Username" placeholderTextColor="#888" value={username} onChangeText={setUsername} autoCapitalize="none"/>}
 <TextInput style={s.input} placeholder="Email" placeholderTextColor="#888" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address"/>
 <TextInput style={s.input} placeholder="Password (8+ characters)" placeholderTextColor="#888" value={password} onChangeText={setPassword} secureTextEntry/>
 <Pressable style={s.primary} onPress={submit} disabled={busy}>{busy?<ActivityIndicator color="white"/>:<Text style={s.primaryText}>{mode==='up'?'Create account':'Sign in'}</Text>}</Pressable>
 <Pressable onPress={()=>setMode(mode==='up'?'in':'up')}><Text style={s.switch}>{mode==='up'?'Already have an account? Sign in':'New to Toky? Create account'}</Text></Pressable>
 <Text style={s.legal}>By continuing, you agree to Toky's Terms and Privacy Policy.</Text></View>
}
const s=StyleSheet.create({page:{flex:1,backgroundColor:'#08090d',padding:26,justifyContent:'center'},logo:{fontSize:34,fontWeight:'900',color:'white',letterSpacing:2},heading:{color:'white',fontSize:25,fontWeight:'900',marginTop:30},sub:{color:'#999',marginTop:8,marginBottom:25},input:{backgroundColor:'#191a22',borderRadius:10,padding:15,color:'white',marginBottom:12,borderWidth:1,borderColor:'#292a35'},primary:{backgroundColor:'#ff3d75',padding:16,borderRadius:10,alignItems:'center',marginTop:8},primaryText:{color:'white',fontWeight:'900'},switch:{color:'white',textAlign:'center',marginTop:22,fontWeight:'700'},legal:{color:'#777',fontSize:11,textAlign:'center',marginTop:35}});
